# 4. Controlled Reconnaissance Lab Guide

## Objective
Practise basic system and network information gathering in a controlled environment, then document observations.

## Prerequisites
- Linux computer or virtual machine.
- Terminal access.
- Nmap and Wireshark, if available.
- Optional Burp Suite or OWASP ZAP.
- Local test application or isolated lab VM for web testing.
- Permission for every target used.

## Safety rules
- Keep practice on localhost or an isolated host-only virtual network.
- Do not scan college, company, public or third-party networks.
- Do not test websites merely because they are publicly accessible.
- Do not attempt exploitation, credential theft or denial-of-service activity.
- Stop if a target behaves unexpectedly or activity is outside scope.

## Exercise A: Linux system information
Run:
```bash
whoami
pwd
ls -la
id
ip addr
ps aux
```
Record current user, working directory, network interface/IP and one process observed.

## Exercise B: DNS lookup
Run:
```bash
nslookup example.com
```
Record the DNS server shown, resolved address(es) and date/time.

## Exercise C: Local Nmap check
Run:
```bash
nmap 127.0.0.1
nmap -sV 127.0.0.1
```
Record Nmap version, command, ports, services, time and limitations. A local scan may show no open ports; that is a valid result.

## Exercise D: Wireshark observation
1. Open Wireshark and select loopback if supported, or an isolated lab interface.
2. Start capture.
3. In another terminal run `nslookup example.com`.
4. Stop capture and apply the `dns` display filter.
5. Observe source/destination and DNS query/response details if visible.

DNS traffic may be encrypted or unavailable on the selected interface depending on system configuration.

## Exercise E: Web proxy familiarization
Use a local or intentionally vulnerable training application only.
1. Start Burp Suite or ZAP.
2. Configure a dedicated browser profile to use the proxy.
3. Open the permitted test application.
4. Inspect one ordinary page request and response.
5. Record HTTP method, path, status code and one non-sensitive header.
6. Do not submit real personal information or credentials.

## Observation record
Fill in actual results using `templates/lab-record-template.md`. Attach sanitized screenshots only if permitted. Never invent scan output or claim an activity was completed if it was not.
