# 1. Linux Fundamentals

## What is Linux?
Linux is an open-source, Unix-like operating system kernel. Linux distributions combine the kernel with system utilities and applications. Examples include Ubuntu, Debian, Fedora and Kali Linux. Linux is common in servers, cloud infrastructure, development and cybersecurity labs.

## Filesystem basics
The Linux filesystem is hierarchical and starts at `/`.

| Directory | Purpose |
|---|---|
| `/` | Filesystem root |
| `/home` | Regular users' home directories |
| `/root` | Root account's home directory |
| `/etc` | System configuration |
| `/var` | Variable data, including logs |
| `/tmp` | Temporary files |
| `/usr` | Applications and shared data |
| `/dev` | Device files |
| `/proc` | Virtual process and kernel information |

## Common commands

| Command | Purpose |
|---|---|
| `pwd` | Show current directory |
| `ls -la` | List all files with details |
| `cd /path` | Change directory |
| `mkdir practice` | Create directory |
| `touch file.txt` | Create an empty file |
| `cp a.txt b.txt` | Copy a file |
| `mv old new` | Move or rename |
| `cat file.txt` | Display file contents |
| `less file.txt` | View long files page by page |
| `find . -name "*.txt"` | Find matching files |

Use deletion commands carefully. Check paths before removing files.

## Users and groups
Linux supports multiple user accounts. Users have user IDs (UIDs), and groups have group IDs (GIDs).

```bash
whoami          # current username
id              # UID, GID and group memberships
groups          # current user's groups
getent passwd   # account database entries
getent group    # group database entries
```

Use `sudo` only when necessary and only after understanding the command.

## File permissions
Permissions control what the owner, group and others can do.

- `r` = read
- `w` = write
- `x` = execute (for directories, traverse/search)

Example: `-rwxr-xr--` means owner `rwx`, group `r-x`, others `r--`.

```bash
chmod u+x script.sh
chmod 640 report.txt
ls -l report.txt
```

Numeric values are `r=4`, `w=2`, `x=1`; therefore `7=rwx`, `6=rw-`, `5=r-x`, `4=r--`.

Ownership can be inspected with `ls -l`. `chown user:group file` changes ownership and generally requires appropriate privileges.

## Processes and services
A process is a running program instance with a process ID (PID).

```bash
ps aux
top
pgrep ssh
```

`kill -TERM PID` requests a process to terminate. Only manage processes you are authorized to control. On many systemd-based systems, `systemctl status service-name` displays service status.

## Linux security basics
- Use strong, unique passwords and MFA where available.
- Keep the OS and applications updated.
- Apply least privilege; avoid routine work as root.
- Review permissions and account access.
- Enable a firewall where appropriate.
- Back up important data.
- Avoid unknown scripts and untrusted commands.
- Protect remote access such as SSH.

## Learning outcome
Navigate the filesystem, inspect files, understand basic permissions, identify users/groups and view running processes.
