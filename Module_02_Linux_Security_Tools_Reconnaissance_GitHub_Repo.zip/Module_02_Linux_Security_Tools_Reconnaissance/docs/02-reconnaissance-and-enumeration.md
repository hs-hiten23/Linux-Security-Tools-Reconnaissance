# 2. Reconnaissance and Network Enumeration

## Reconnaissance
Reconnaissance is the information-gathering phase of a security assessment. It helps an authorized tester understand the scope, technology and visible information about a target before further testing. Confirm authorization and scope first.

## Passive vs active reconnaissance

| Passive | Active |
|---|---|
| Collects information without directly probing target systems. | Interacts directly with target systems or services. |
| Examples: public documentation and approved public DNS information. | Examples: authorized port scans and test requests. |
| Usually lower impact, but privacy and terms still apply. | May generate alerts or affect performance; requires explicit authorization. |

## DNS and domain concepts
DNS (Domain Name System) maps domain names to records such as IP addresses and mail servers.

| Record | Meaning |
|---|---|
| A | IPv4 address |
| AAAA | IPv6 address |
| CNAME | Alias to another domain name |
| MX | Mail exchange server |
| NS | Authoritative name server |
| TXT | Text data, often verification or email policy |
| SOA | Start of Authority information |
| PTR | Reverse lookup record |

## Basic DNS commands
Use a domain you own, a training domain, or the reserved example domain `example.com`.

```bash
nslookup example.com
dig example.com A
dig example.com AAAA
dig example.com MX
dig example.com NS
```

Results can vary because of DNS configuration, caching and changes over time.

## Network enumeration
Network enumeration identifies hosts, network services and related details within an explicitly authorized scope. Record:
- Lab host identifier and IP address.
- Open/listening ports.
- Detected service and version, where available.
- Date/time and tool/command used.
- Observations, limitations and uncertainty.

## Responsible workflow
1. Confirm written authorization and scope.
2. Identify permitted targets and testing window.
3. Begin with approved passive information gathering.
4. Perform active checks only if included in scope.
5. Record commands, timestamps and observations.
6. Validate findings without disrupting systems.
7. Report evidence, impact, limitations and recommendations.
8. Stop if activity is outside scope or instability occurs.

A publicly reachable system is not automatically authorized for testing. Do not bypass access controls, exploit vulnerabilities, collect credentials or scan networks without permission.
