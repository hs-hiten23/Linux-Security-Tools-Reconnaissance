# 3. Security Tools

Use these tools only in a lab or against systems for which you have explicit permission.

## Nmap
Nmap (Network Mapper) is used for network discovery and security auditing. It can identify hosts, open ports and service information.

```bash
nmap 127.0.0.1
nmap -sV 127.0.0.1
```

`127.0.0.1` is the local loopback interface. `-sV` requests service/version detection. Scan another host only if it is explicitly in your authorized lab scope. An open port does not automatically indicate a vulnerability.

## Wireshark
Wireshark is a graphical network protocol analyzer for capturing and inspecting packets.

Basic workflow:
1. Open Wireshark and select a lab interface.
2. Start capture.
3. Generate benign test traffic, such as a DNS lookup.
4. Stop capture and inspect packets.
5. Save captures only if permitted and free of sensitive information.

Useful display filters:
```text
dns
tcp
udp
http
tls
ip.addr == 127.0.0.1
```
Display filters narrow the packets shown; they do not alter the original capture.

## Burp Suite
Burp Suite is a web application testing platform. Its Proxy can sit between a browser and a web application to inspect HTTP requests and responses.

Safe beginner workflow:
1. Use a local or intentionally vulnerable training application.
2. Configure a dedicated test browser to use Burp's proxy.
3. Confirm only the lab application is being tested.
4. Inspect ordinary requests in Proxy/HTTP history.
5. Observe methods, paths, headers, parameters, status codes and responses.
6. Never capture real credentials or other users' data.

Features vary by edition.

## OWASP ZAP
OWASP Zed Attack Proxy (ZAP) is an open-source web application security testing tool. It can proxy browser traffic and assist with passive and active testing.

Safe beginner workflow:
1. Start ZAP and use a dedicated test browser.
2. Configure the browser to use the proxy.
3. Visit only a local or explicitly authorized training application.
4. Review the Sites tree, History and passive alerts.
5. Read evidence and confidence; verify before reporting.
6. Use active scanning only when explicitly authorized.

## Tool comparison

| Tool | Main purpose | Typical output |
|---|---|---|
| Nmap | Network discovery and port/service enumeration | Hosts, ports, service details |
| Wireshark | Packet and protocol analysis | Captured packets and protocol fields |
| Burp Suite | Web request/response inspection | HTTP history and request/response details |
| OWASP ZAP | Web application security testing | Sites, history, alerts and scan results |

Tool output can be incomplete or inaccurate due to filtering, permissions, configuration, encryption or tool limitations. Validate observations and state uncertainty.
