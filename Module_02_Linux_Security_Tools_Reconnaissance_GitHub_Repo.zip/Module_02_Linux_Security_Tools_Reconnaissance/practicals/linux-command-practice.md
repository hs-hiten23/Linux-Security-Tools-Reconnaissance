# Practical 1: Linux Command Practice

## Aim
Practise directory navigation, file operations, permissions, users/groups and process inspection.

## Procedure
```bash
pwd
ls -la
mkdir module2-practice
cd module2-practice
touch sample.txt
echo "Linux practice" > sample.txt
cat sample.txt
cp sample.txt copy.txt
mv copy.txt renamed.txt
ls -l
```

Identity and permissions:
```bash
whoami
id
groups
chmod 640 sample.txt
ls -l sample.txt
```

Processes:
```bash
ps aux
top
```
Press `q` to exit `top`.

## Observations
- Current user: [ADD YOUR OBSERVATION]
- Permission shown for sample.txt: [ADD YOUR OBSERVATION]
- One process observed: [ADD YOUR OBSERVATION]

## Conclusion
[WRITE A CONCLUSION BASED ON YOUR PRACTICE]
