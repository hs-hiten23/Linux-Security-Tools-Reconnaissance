# Practical 4: Wireshark Packet Analysis

## Aim
Capture and inspect basic network traffic in a controlled lab.

## Procedure
1. Open Wireshark.
2. Select loopback if supported, or an isolated lab interface.
3. Start capture.
4. Generate a DNS lookup:
```bash
nslookup example.com
```
5. Stop capture and apply this display filter:
```text
dns
```

Other filters: `tcp`, `udp`, `tls`, `ip.addr == 127.0.0.1`.

## Observe
- Source address
- Destination address
- Protocol
- Packet length
- DNS query and response, if visible

## Observation table

| Field | Actual observation |
|---|---|
| Capture interface | [ADD YOUR OBSERVATION] |
| Filter | dns |
| Protocol observed | [ADD YOUR OBSERVATION] |
| Source/destination | [ADD YOUR OBSERVATION] |
| DNS query | [ADD YOUR OBSERVATION] |

Packet captures may contain sensitive information. Capture only your own lab traffic and do not publish credentials, tokens, personal data or private captures.

## Conclusion
[WRITE WHAT YOU LEARNED FROM YOUR CAPTURE]
