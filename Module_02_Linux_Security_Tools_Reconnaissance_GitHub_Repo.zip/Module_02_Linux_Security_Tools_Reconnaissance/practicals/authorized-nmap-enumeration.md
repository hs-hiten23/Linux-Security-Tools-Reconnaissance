# Practical 3: Authorized Nmap Enumeration

## Aim
Understand basic port/service discovery on the local machine or an explicitly authorized lab host.

## Scope
This exercise uses `127.0.0.1` (local loopback). Do not substitute a third-party/public target without explicit authorization.

## Commands
```bash
nmap 127.0.0.1
nmap -sV 127.0.0.1
```

## Key terms
- Host discovery: determines whether a host appears reachable.
- Port: logical endpoint for network communication.
- Open port: a service is listening and accepting connections.
- Service detection: attempts to identify the service/version on a port.

## Observation table

| Field | Actual result |
|---|---|
| Nmap version | [ADD YOUR OBSERVATION] |
| Target | 127.0.0.1 |
| Open ports | [ADD YOUR OBSERVATION] |
| Services | [ADD YOUR OBSERVATION] |
| Scan date/time | [ADD YOUR OBSERVATION] |
| Limitations | [ADD YOUR OBSERVATION] |

An open port is not automatically a vulnerability. Do not attempt exploitation in this beginner exercise.

## Conclusion
[WRITE A CONCLUSION BASED ON YOUR SCAN]
