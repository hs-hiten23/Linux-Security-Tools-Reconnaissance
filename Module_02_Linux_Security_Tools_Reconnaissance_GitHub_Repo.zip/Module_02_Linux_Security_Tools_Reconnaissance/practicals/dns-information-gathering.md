# Practical 2: DNS Information Gathering

## Aim
Understand how DNS resolves domain names and inspect common record types.

## Commands
```bash
nslookup example.com
dig example.com A
dig example.com AAAA
dig example.com MX
dig example.com NS
```
If `dig` is unavailable, use `nslookup` or install DNS utilities using your distribution's trusted package manager.

## Record types
- A: IPv4 address
- AAAA: IPv6 address
- MX: Mail exchange
- NS: Name server

## Observation table

| Query | Actual result |
|---|---|
| A record | [ADD YOUR OBSERVATION] |
| AAAA record | [ADD YOUR OBSERVATION] |
| MX record | [ADD YOUR OBSERVATION] |
| NS record | [ADD YOUR OBSERVATION] |
| DNS server | [ADD YOUR OBSERVATION] |

## Conclusion
[WRITE WHAT YOU LEARNED FROM THE ACTUAL RESULTS]
