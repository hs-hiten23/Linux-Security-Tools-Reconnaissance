# Lab Record – Module 02

**Student:** [YOUR NAME]  
**Module:** Linux, Security Tools & Reconnaissance  
**Date:** [DATE]  
**Practical title:** [TITLE]

## Aim
[STATE THE AIM]

## Environment
- Operating system: [DETAILS]
- Tool and version: [DETAILS]
- Authorized target/scope: [DETAILS]
- Date and time: [DETAILS]

## Procedure
1. [STEP 1]
2. [STEP 2]
3. [STEP 3]

## Commands / Configuration
```text
[PASTE COMMANDS OR CONFIGURATION]
```

## Observations
[RECORD ACTUAL RESULTS]

## Screenshots
[ADD SANITIZED SCREENSHOT REFERENCES IF PERMITTED]

## Result and conclusion
[SUMMARIZE ACTUAL OBSERVATIONS AND LEARNING]

## Safety confirmation
I performed this activity only on my own system or an explicitly authorized lab target. I excluded secrets and personal data.
