# Reconnaissance Findings Report – Module 02

## 1. Assessment details
- Title: [TITLE]
- Date/time: [DATE AND TIME]
- Tester: [NAME]
- Authorized scope: [TARGETS / LAB]
- Permission/reference: [APPROVAL DETAILS, IF APPLICABLE]

## 2. Objective
[DESCRIBE THE OBJECTIVE]

## 3. Methodology
[DESCRIBE PASSIVE OR ACTIVE METHODS USED]

## 4. Tools
| Tool | Version | Purpose |
|---|---|---|
| Linux utilities | [VERSION] | System information |
| Nmap | [VERSION] | Authorized port/service enumeration |
| Wireshark | [VERSION] | Packet analysis |
| Burp Suite / OWASP ZAP | [VERSION] | Web request inspection |

## 5. Findings
For each finding, record ID, title, evidence, affected lab asset, impact (if assessed), confidence, limitations and recommendation.

Do not report a vulnerability based only on a tool alert. Validate evidence and state uncertainty.

## 6. Summary
[SUMMARIZE ACTUAL OBSERVATIONS]

## 7. Limitations
[DESCRIBE WHAT WAS NOT TESTED OR COULD NOT BE VERIFIED]

## 8. Safety statement
All active testing was limited to systems for which permission was granted. Sensitive data, credentials, tokens and private packet captures are excluded.
