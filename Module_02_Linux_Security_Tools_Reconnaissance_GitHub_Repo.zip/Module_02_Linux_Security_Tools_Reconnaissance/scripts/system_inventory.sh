#!/usr/bin/env bash
# Read-only basic Linux inventory helper for Module 02.
# Does not scan networks, change settings, or collect passwords.

set -u

echo "=== Basic System Inventory ==="
echo "Date: $(date)"
echo "User: $(whoami)"
echo "Hostname: $(hostname)"
echo
echo "=== Operating System ==="
if [ -r /etc/os-release ]; then
  grep -E '^(PRETTY_NAME|VERSION)=' /etc/os-release
else
  uname -srm
fi
echo
echo "=== Kernel ==="
uname -r
echo
echo "=== Current Directory ==="
pwd
echo
echo "=== Network Interfaces ==="
if command -v ip >/dev/null 2>&1; then
  ip -brief addr
else
  echo "'ip' command not found."
fi
echo
echo "=== User and Groups ==="
id
echo
echo "=== Process Snapshot (first 10 lines) ==="
ps aux | head -n 10
echo
echo "Inventory complete. Review output and redact private host/network details before sharing."
